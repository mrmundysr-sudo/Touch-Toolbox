package dev.touchtoolkit

import android.view.MotionEvent
import android.view.View
import androidx.test.core.app.ApplicationProvider
import org.junit.Assert.assertEquals
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertTrue
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.Robolectric
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config

/** Makes sure the activity assembles its chrome and starts without crashing. */
@RunWith(RobolectricTestRunner::class)
@Config(sdk = [33])
class MainActivityTest {

    @Test
    fun `horizontal tray scrolling never dismisses it`() {
        var dismissals = 0
        val listener = TraySwipeDismissListener(8f, 48f) { dismissals++ }
        val view = View(ApplicationProvider.getApplicationContext())

        send(listener, view, MotionEvent.ACTION_DOWN, 300f, 900f)
        send(listener, view, MotionEvent.ACTION_MOVE, 40f, 904f)
        send(listener, view, MotionEvent.ACTION_UP, 40f, 904f)

        assertEquals(0, dismissals)
    }

    @Test
    fun `only a deliberate downward swipe from the tray dismisses it`() {
        var dismissals = 0
        val listener = TraySwipeDismissListener(8f, 48f) { dismissals++ }
        val view = View(ApplicationProvider.getApplicationContext())

        send(listener, view, MotionEvent.ACTION_DOWN, 300f, 900f)
        send(listener, view, MotionEvent.ACTION_MOVE, 300f, 970f)
        send(listener, view, MotionEvent.ACTION_UP, 300f, 970f)
        assertEquals(1, dismissals)

        send(listener, view, MotionEvent.ACTION_DOWN, 300f, 900f)
        send(listener, view, MotionEvent.ACTION_MOVE, 300f, 820f)
        send(listener, view, MotionEvent.ACTION_UP, 300f, 820f)
        assertEquals("an upward swipe must not dismiss the tray", 1, dismissals)
    }

    private fun send(listener: View.OnTouchListener, view: View, action: Int, x: Float, y: Float) {
        val event = MotionEvent.obtain(0L, 0L, action, x, y, 0)
        try {
            listener.onTouch(view, event)
        } finally {
            event.recycle()
        }
    }

    @Test
    fun `the activity starts and shows the tool chrome`() {
        val controller = Robolectric.buildActivity(MainActivity::class.java).setup()
        val activity = controller.get()
        assertNotNull(activity)
        assertTrue("activity should not be finishing", !activity.isFinishing)
        controller.pause().stop().destroy()
    }

    @Test
    fun `a project starts on a fresh surface`() {
        val project = ProjectStore.loadCurrent(ApplicationProvider.getApplicationContext())
        // A brand new install has no saved project, and the default is a clean surface.
        if (project == null) {
            val fresh = Project()
            assertTrue(fresh.items.isEmpty())
            assertTrue(fresh.worldW > 0f && fresh.worldH > 0f)
        }
    }
}
