package dev.touchtoolkit

import androidx.test.core.app.ApplicationProvider
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertTrue
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.Robolectric
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config

/** Makes sure the activity assembles its chrome and starts without crashing. */
@RunWith(RobolectricTestRunner::class)
@Config(sdk = [33])
class MainActivityTest {

    @Test
    fun `the activity starts and shows the tool chrome`() {
        val controller = Robolectric.buildActivity(MainActivity::class.java).setup()
        val activity = controller.get()
        assertNotNull(activity)
        assertTrue("activity should not be finishing", !activity.isFinishing)
        controller.pause().stop().destroy()
    }

    @Test
    fun `a project starts on a fresh surface`() {
        val project = ProjectStore.loadCurrent(ApplicationProvider.getApplicationContext())
        // A brand new install has no saved project, and the default is a clean surface.
        if (project == null) {
            val fresh = Project()
            assertTrue(fresh.items.isEmpty())
            assertTrue(fresh.worldW > 0f && fresh.worldH > 0f)
        }
    }
}
